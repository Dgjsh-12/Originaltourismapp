import { Hook } from '@oclif/config';
export declare const analytics: Hook<'prerun'>;
